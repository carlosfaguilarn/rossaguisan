---
layout: docs
title: Download
description: Download Rocket to get the full project files including Sass and Gulpfile
group: getting-started
aliases:
  - "/getting-started/"
toc: true
---

## Download

- Download Rocket from [Themesberg]({{< param product_page >}}).