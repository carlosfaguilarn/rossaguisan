---
layout: docs
title: License
description: Read more about the licensing for Rocket
group: getting-started
aliases:
  - "/getting-started/"
toc: true
---

## License

Please check our official [licensing page](https://themesberg.com/licensing) to learn more about our licensing.